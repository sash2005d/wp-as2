<?php
/*
 * Template Name: Custom Post-Type Book Reviews
 * Template Post Type: books-reviews
 */

get_header();
$featuredImg = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
?>
<header class="hero-single-book-rew fluid" style="background: url('<?php echo $featuredImg[0];?>')">
<div class="content container">
    <h1><?php the_title(); ?></h1>
</div>


</header>
<main>
    <article>
         <?php the_content(); ?>
    </article>
    <aside>
        <?php 
        $the_query = new WP_Query(array('post_type' => 'books-reviews', 'post_per_page' =>3, 'order' => 'desc'));
        while($the_query->have_posts()) : $the_query -> the_post();
        
        ?>
        <div class="card">
            <a href="<?php the_permalink(); ?>">
                <img src="<?php echo $featuredImg[0]; ?>" alt="bookcover <?php the_title();?>">
            </a>
            <a href="<?php the_permalink(); ?>"><?php the_title();?></a>
        </div>
                    <?php
            endwhile;
            wp_reset_postdata();
            ?>

    </aside>
</main>
<?php  get_footer();?>

