<?php
/*
 * Template Name: Homepage
 * Template Post Type: page
 * Description: A custom template for the homepage.
 */

get_header(); ?>

<main id="primary" class="site-main">
    <section class="hero">
        <div class="container">
            <h1 class="display-4">Best Books</h1>
            <p class="lead">Discover the finest selection of books handpicked by our team.</p>
            <a href="<?php echo esc_url( home_url( '/shop' ) ); ?>" class="btn btn-primary btn-lg">Shop Now</a>
        </div>
    </section>

    <section class="best-selling">
        <div class="container">
            <h2>Best Selling</h2>
            <!-- Add your best selling section content here -->
        </div>
    </section>

    <section class="books-reviews">
        <div class="container">
            <h2>Books Reviews</h2>
            <div class="row">
                <?php
                $args = array(
                    'post_type' => 'book_review',
                    'posts_per_page' => 3,
                );
                $query = new WP_Query( $args );
                if ( $query->have_posts() ) :
                    while ( $query->have_posts() ) : $query->the_post();
                ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <img src="<?php the_post_thumbnail_url( 'medium' ); ?>" class="card-img-top" alt="<?php the_title_attribute(); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php the_title(); ?></h5>
                            <p class="card-text"><?php echo wp_trim_words( get_the_excerpt(), 20 ); ?></p>
                            <p class="card-text"><small class="text-muted">By <?php the_author(); ?></small></p>
                            <a href="<?php the_permalink(); ?>" class="btn btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                    echo '<p>No books reviews found.</p>';
                endif;
                ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
