<?php

// add menu to the theme 
function bookstore_menus(){
    register_nav_menus( array(
        'header' => 'Header menu',
        'footer' => 'Footer menu'
    ));
}

add_action('after_setup_theme', 'bookstore_menus');

// add option for thumbnail
add_theme_support('post-thumbnails');

// setup custom footer widgets
// Register footer widget areas
function bookshop_register_footer_widgets() {
    // First widget area
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area One', 'bookshop' ),
        'id'            => 'footer-widget-area-one',
        'description'   => __( 'Widgets placed here will appear in the first column of the footer.', 'bookshop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>'
       
    ) );

    // Second widget area
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area Two', 'bookshop' ),
        'id'            => 'footer-widget-area-two',
        'description'   => __( 'Widgets placed here will appear in the second column of the footer.', 'bookshop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>'
    ) );

    // Third widget area
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area Three', 'bookshop' ),
        'id'            => 'footer-widget-area-three',
        'description'   => __( 'Widgets placed here will appear in the third column of the footer.', 'bookshop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>'
      
    ) );
}
add_action( 'widgets_init', 'bookshop_register_footer_widgets' );


// registration custom posttype for books review
function custom_post_type_book_reviews() {
    $labels = array(
        'name'                  => _x( 'Book Reviews', 'Post Type General Name', 'text_domain' ),
        'singular_name'         => _x( 'Book Review', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'             => __( 'Book Reviews', 'text_domain' ),
        'name_admin_bar'        => __( 'Book Review', 'text_domain' ),
        'archives'              => __( 'Book Review Archives', 'text_domain' ),
        'attributes'            => __( 'Book Review Attributes', 'text_domain' ),
        'parent_item_colon'     => __( 'Parent Book Review:', 'text_domain' ),
        'all_items'             => __( 'All Book Reviews', 'text_domain' ),
        'add_new_item'          => __( 'Add New Book Review', 'text_domain' ),
        'add_new'               => __( 'Add New', 'text_domain' ),
        'new_item'              => __( 'New Book Review', 'text_domain' ),
        'edit_item'             => __( 'Edit Book Review', 'text_domain' ),
        'update_item'           => __( 'Update Book Review', 'text_domain' ),
        'view_item'             => __( 'View Book Review', 'text_domain' ),
        'view_items'            => __( 'View Book Reviews', 'text_domain' ),
        'search_items'          => __( 'Search Book Reviews', 'text_domain' ),
        'not_found'             => __( 'Not found', 'text_domain' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
        'featured_image'        => __( 'Featured Image', 'text_domain' ),
        'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
        'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
        'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
        'insert_into_item'      => __( 'Insert into book review', 'text_domain' ),
        'uploaded_to_this_item' => __( 'Uploaded to this book review', 'text_domain' ),
        'items_list'            => __( 'Book Reviews list', 'text_domain' ),
        'items_list_navigation' => __( 'Book Reviews list navigation', 'text_domain' ),
        'filter_items_list'     => __( 'Filter book reviews list', 'text_domain' )
    );
    $args = array(
        'label'                 => __( 'Book Review', 'text_domain' ),
        'description'           => __( 'Book Reviews', 'text_domain' ),
        'labels'                => $labels,
        'query_var'             => true,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt','author', 'page-attributes', 'post-formats'),
        'taxonomies'            => array( 'category', 'post_tag' ),
        'hierarchical'          => false,
        'public'                => true,
        'menu_icon'             => 'dashicons-book-alt',
        'has_archive'           => true,
        'rewrite'               => array( 'slug' => 'book-reviews' )
    );
    register_post_type( 'book_review', $args );
}
add_action( 'init', 'custom_post_type_book_reviews', 0 );
