
    <!-- footer -->
    <footer class="container">
        <!-- footer widgets -->
        
          <div class="first-widget">
            <?php dynamic_sidebar('footer-widget-area-one')?>
          </div>
          <div class="second-widget">
            <?php dynamic_sidebar('footer-widget-area-two')?>
          </div>
          <div class="third-widget">
            <?php dynamic_sidebar('footer-widget-area-three')?>
          </div>
        
    </footer>
    <!-- footer ends -->

    <!-- bootstrap js  -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js
    "></script>
    <?php wp_footer(); ?>
  </body>
</html>
